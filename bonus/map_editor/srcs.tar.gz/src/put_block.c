/*
** EPITECH PROJECT, 2018
** my_runner
** File description:
** put_block.c
*/

#include <SFML/Graphics.h>
#include "edit.h"
#include "my.h"

void put_block(edit_t *edit, sfRenderWindow *window, int **map)
{
    sfVector2i pos;
    int max_x = edit->width;
    int max_y = edit->height;

    if (sfMouse_isButtonPressed(sfMouseLeft)) {
        pos = get_pos_map(edit, window);
        if (pos.x >= max_x || pos.y >= max_y);
        else {
            map[pos.y - edit->y_offset][pos.x - edit->x_offset] = edit->block;
        }
    }
}
